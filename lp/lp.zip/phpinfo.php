<?php 
 echo "<h1>Hola!</h1>";

?>